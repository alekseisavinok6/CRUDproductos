package com.example.tiendaproductos.entity;

public class Producto {
    private int id;
    private String codigo;
    private String nombre;
    private int precio;

    public Producto(){

    }

    public Producto(String codigo, String nombre, int precio) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.precio = precio;
    }

    public Producto(int id, String codigo, String nombre, int precio) {
        this.id = id;
        this.codigo = codigo;
        this.nombre = nombre;
        this.precio = precio;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {

        return String.format("%-4d %-20s %-20s %-15s %-25s %-35s",
                id,
                codigo,
                nombre,
                precio);
    }
}


/*
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;


    @Override
    public String toString() {

        return String.format("%-4d %-20s %-20s %-15s %-25s %-35s",
                id,
                nombre,
                apellido,
                telefono,
                correo,
                direccion);
    }
}
 */
